export const LOGIN = 'LOGIN';
export const LOGOUT = 'LOGOUT';
export const REGISTER = 'REGISTER';

export const BRIDGEFY_START = 'BRIDGEFY_START';
export const BRIDGEFY_STOP = 'BRIDGEFY_STOP';

export const CHAT_CREATE = 'CHAT_CREATE';
export const CHAT_ACCEPT = 'CHAT_ACCEPT';

export const DEVICE_CONNECT = 'DEVICE_CONNECT';
export const DEVICE_DISCONNECT = 'DEVICE_DISCONNECT';
export const DEVICE_INIT = 'DEVICE_INIT';

export const MESSAGE_ADD = 'MESSAGE_ADD';
export const MESSAGE_DELETE = 'MESSAGE_DELETE';
export const MESSAGE_READ = 'MESSAGE_READ';
export const MESSAGE_EDIT = 'MESSAGE_EDIT';
export const MESSAGE_INIT = 'MESSAGE_INIT';
export const MESSAGE_REFRESH = 'MESSAGE_REFRESH';

export const SETTING_SAVE = 'SETTING_SAVE';
