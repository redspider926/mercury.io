import * as actionTypes from './actionTypes';

export function bridgefyStart(user) {
  return {
    type: actionTypes.BRIDGEFY_START,
    payload: user,
  };
}

export function bridgefyStop() {
  return {
    type: actionTypes.BRIDGEFY_STOP,
  };
}

export function messageRefresh(refreshKey) {
  return {
    type: actionTypes.MESSAGE_REFRESH,
    payload: refreshKey,
  };
}
