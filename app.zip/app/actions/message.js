import * as actionTypes from './actionTypes';

export function messageAdd(message) {
  return {
    type: actionTypes.MESSAGE_ADD,
    payload: message,
  };
}

export function messageEdit(messageId, text) {
  return {
    type: actionTypes.MESSAGE_EDIT,
    payload: {
      messageId: messageId,
      text: text,
    },
  };
}

export function messageDelete(messageId) {
  return {
    type: actionTypes.MESSAGE_DELETE,
    payload: messageId,
  };
}

export function messageRead(chatId) {
  return {
    type: actionTypes.MESSAGE_READ,
    payload: chatId,
  };
}

export function messageInit() {
  return {
    type: actionTypes.MESSAGE_INIT,
  };
}
