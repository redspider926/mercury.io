import * as actionTypes from './actionTypes';

export function settingSave(setting) {
  return {
    type: actionTypes.SETTING_SAVE,
    setting,
  };
}
