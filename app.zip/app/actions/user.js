import * as actionTypes from './actionTypes';

export function chatCreate(chat) {
  return {
    type: actionTypes.CHAT_CREATE,
    payload: chat,
  };
}

export function chatAccept(chat) {
  return {
    type: actionTypes.CHAT_ACCEPT,
    payload: chat,
  };
}

export function deviceConnect(device) {
  return {
    type: actionTypes.DEVICE_CONNECT,
    payload: device,
  };
}

export function deviceDisconnect(device) {
  return {
    type: actionTypes.DEVICE_DISCONNECT,
    payload: device,
  };
}

export function deviceInit() {
  return {
    type: actionTypes.DEVICE_INIT,
  };
}
