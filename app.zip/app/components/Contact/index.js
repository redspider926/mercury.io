import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import styles from './style';

import Icon from '../Icon';
import * as color from '@config/color';
import * as images from '@config/images';

const Contact = (props) => {
  return (
    <>
      <TouchableOpacity
        style={styles.root}
        onPress={() =>
          props.navigation.navigate('Message', {
            id: props.id,
            name: props.name,
            isConnected: props.isConnected,
            users: props.users,
          })
        }>
        <View style={styles.view1}>
          {props.users.length === 2 ? (
            <Icon
              color={color.second}
              source={images.icons.profile}
              size={15}
            />
          ) : (
            <Icon color={color.second} source={images.icons.group} size={20} />
          )}

          <View
            style={[
              styles.state,
              props.isConnected ? styles.connected : styles.disconnected,
            ]}
          />
        </View>
        <View style={styles.view2}>
          <Text style={styles.name}>{props.name}</Text>
          <Text style={styles.chat}>{props.finalChat}</Text>
        </View>
        <View style={styles.view3}>
          {props.notification > 0 ? (
            <View style={styles.notification}>
              <Text style={styles.textNotification}>{props.notification}</Text>
            </View>
          ) : (
            <></>
          )}
        </View>
      </TouchableOpacity>
    </>
  );
};

export default Contact;
