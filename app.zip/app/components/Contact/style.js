import {StyleSheet} from 'react-native';
import * as color from '@config/color';
import * as images from '@config/images';
import * as dimension from '@config/dimension';

export default StyleSheet.create({
  root: {
    width: '100%',
    display: 'flex',
    flexDirection: 'row',
    marginBottom: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },

  view1: {
    width: dimension.size.size_header,
    height: dimension.size.size_header,
    borderRadius: 25,
    backgroundColor: color.first,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 20,
  },

  view2: {
    height: dimension.size.size_header,
    justifyContent: 'space-between',
    flex: 1,
  },

  view3: {
    display: 'flex',
    flexDirection: 'column',
    height: dimension.size.size_header,
    justifyContent: 'center',
    alignItems: 'flex-end',
  },

  avatarText: {
    color: color.second,
    fontSize: 24,
    fontWeight: 'bold',
  },

  name: {fontSize: 18},

  chat: {},

  notification: {
    backgroundColor: color.orange,
    width: 20,
    height: 20,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
  },

  textNotification: {
    color: color.second,
  },

  state: {
    width: 12,
    height: 12,
    borderRadius: 12,
    position: 'absolute',
    right: 0,
    bottom: 0,
    elevation: 3,
  },

  connected: {
    backgroundColor: color.success,
  },

  disconnected: {
    backgroundColor: color.gray,
  },
});
