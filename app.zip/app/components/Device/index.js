import React, {useState} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import styles from './style';
import Icon from '../Icon';
import * as color from '@config/color';
import * as dimension from '@config/dimension';
import * as images from '@config/images';

const Device = (props) => {
  const {id, name, onPress, isSelected, style} = props;

  return (
    <>
      <TouchableOpacity style={styles.root} onPress={props.onPress}>
        <View style={styles.view1}>
          <Icon
            color={color.white}
            source={images.icons.bluetooth_device}
            size={20}
          />
        </View>
        <View style={styles.view2}>
          <Text style={styles.userName}>{props.name}</Text>
        </View>
        <View style={styles.view3}>
          {style === 'option' ? (
            <View style={styles.optionContainer}>
              {isSelected ? (
                <Icon
                  color={color.first}
                  source={images.icons.bluetooth_device}
                  size={20}
                />
              ) : (
                <></>
              )}
            </View>
          ) : (
            <View style={styles.checkContainer}>
              {isSelected ? (
                <Icon
                  color={color.first}
                  source={images.icons.bluetooth_device}
                  size={20}
                />
              ) : (
                <></>
              )}
            </View>
          )}
        </View>
      </TouchableOpacity>
    </>
  );
};

export default Device;
