import {StyleSheet} from 'react-native';
import * as color from '@config/color';
import * as images from '@config/images';
import * as dimension from '@config/dimension';

export default StyleSheet.create({
  root: {
    width: '100%',
    display: 'flex',
    flexDirection: 'row',
    marginBottom: 20,
  },

  view1: {
    width: dimension.size.size_normal,
    height: dimension.size.size_normal,
    borderRadius: 10,
    backgroundColor: color.first,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },

  view2: {
    height: dimension.size.size_normal,
    justifyContent: 'center',
    flex: 1,
  },

  view3: {
    width: 50,
    height: dimension.size.size_normal,
    justifyContent: 'center',
    alignItems: 'flex-end',
  },

  avatarText: {
    color: color.second,
    fontSize: 24,
    fontWeight: 'bold',
  },

  userName: {fontSize: 18},

  optionContainer: {
    width: 25,
    height: 25,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
    borderColor: color.first,
    borderWidth: 2,
  },

  checkContainer: {
    width: 25,
    height: 25,
    borderRadius: 5,
    alignItems: 'center',
    justifyContent: 'center',
    borderColor: color.first,
    borderWidth: 2,
  },

  state: {
    width: 12,
    height: 12,
    borderRadius: 12,
    position: 'absolute',
    right: 0,
    bottom: 0,
    elevation: 3,
  },

  activeTrue: {
    backgroundColor: color.success,
  },

  activeFalse: {
    backgroundColor: color.gray,
  },

  isSelected: {
    width: 10,
    height: 10,
    backgroundColor: color.first,
    borderRadius: 10,
  },
});
