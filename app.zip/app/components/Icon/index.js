import React from 'react';
import {Image} from 'react-native';
import styles from './style';

const Icon = (props) => {
  return (
    <>
      <Image
        style={[
          styles.icon,
          {tintColor: props.color, width: props.size, height: props.size},
        ]}
        source={props.source}
      />
    </>
  );
};

export default Icon;
