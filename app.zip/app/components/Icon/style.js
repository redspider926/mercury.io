import {StyleSheet} from 'react-native';
import * as dimension from '@config/dimension';

export default StyleSheet.create({
  icon: {
    height: dimension.size.size2,
    width: dimension.size.size2,
  },
});
