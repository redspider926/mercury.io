import React from 'react';
import {View, TextInput, Text} from 'react-native';
import Icon from '@components/Icon';

import * as color from '@config/color';
import * as images from '@config/images';

import styles from './style';

const Input = (props) => {
  const secureTextEntry = props.type === 'password' ? true : false;
  let src = '';
  switch (props.type) {
    case 'email':
      src = images.icons.email;
      break;
    case 'password':
      src = images.icons.password;
      break;
    case 'username':
      src = images.icons.profile;
      break;
    case 'search':
      src = images.icons.search;
      break;
    default:
      break;
  }

  return (
    <>
      <View style={styles.view}>
        <View style={styles.iconView}>
          <Icon source={src} color={color.first} size={20} />
        </View>
        <TextInput
          style={styles.input}
          placeholder={props.placeholder}
          secureTextEntry={secureTextEntry}
          onChangeText={props.onChangeText}
          value={props.value}
        />
      </View>
    </>
  );
};

export default Input;
