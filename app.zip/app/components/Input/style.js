import {StyleSheet} from 'react-native';
import * as dimension from '@config/dimension';
import * as color from '@config/color';

export default StyleSheet.create({
  input: {
    fontSize: dimension.fontSize.font1,
    height: '100%',
    flex: 1,
    paddingLeft: 10,
  },

  view: {
    width: '100%',
    height: dimension.size.size_normal,
    backgroundColor: color.gray,
    borderRadius: dimension.size.size1,
    display: 'flex',
    flexDirection: 'row',
    marginTop: 20,
    elevation: 2,
  },

  iconView: {
    width: dimension.size.size_normal,
    height: dimension.size.size_normal,
    backgroundColor: color.second,
    borderTopLeftRadius: dimension.size.size1,
    borderBottomLeftRadius: dimension.size.size1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
