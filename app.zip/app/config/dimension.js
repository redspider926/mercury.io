export const fontSize = {
  font1: 14,
  font2: 18,
  font3: 22,
  font4: 40,
  font5: 50,
};

export const size = {
  size1: 10,
  size2: 20,
  size3: 30,
  size4: 40,
  size_normal: 40,
  size_header: 50,
  padding: 16,
};
