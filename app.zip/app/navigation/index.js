import * as React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import FlashMessage from 'react-native-flash-message';
import Icon from '@components/Icon';
import * as images from '@config/images';
import * as color from '@config/color';
import * as dimension from '@config/dimension';

import Login from '../screens/Login';
import Register from '../screens/Register';
// import Bluetooth from '../screens/Bluetooth';
import Permissions from '../screens/Permissions';
import Progress from '../screens/Progress';
import Start from '../screens/Start';
import Help from '../screens/Help';
import Broadcast from '../screens/Broadcast';
import Setting from '../screens/Setting';
import Chat from '../screens/Chat';
import NewContact from '../screens/NewContact';
import NewSecret from '../screens/NewSecret';
import NewGroup from '../screens/NewGroup';
import BroadcastMessage from '../screens/BroadcastMessage';
import Message from '../screens/Message';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

function Navigation() {
  return (
    <>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Login">
          <Stack.Screen
            name="Login"
            component={Login}
            options={{headerShown: false, gestureEnabled: false}}
          />
          <Stack.Screen
            name="Register"
            component={Register}
            options={{headerShown: false, gestureEnabled: false}}
          />
          <Stack.Screen
            name="Permissions"
            component={Permissions}
            options={{headerShown: false, gestureEnabled: false}}
          />
          <Stack.Screen
            name="Progress"
            component={Progress}
            options={{headerShown: false, gestureEnabled: false}}
          />
          <Stack.Screen
            name="Start"
            component={Start}
            options={{headerShown: false, gestureEnabled: false}}
          />
          <Stack.Screen
            name="TabNav"
            component={TabNav}
            options={{headerShown: false, gestureEnabled: false}}
          />
          <Stack.Screen
            name="NewContact"
            component={NewContact}
            options={{headerShown: false, gestureEnabled: false}}
          />
          <Stack.Screen
            name="NewSecret"
            component={NewSecret}
            options={{headerShown: false, gestureEnabled: false}}
          />
          <Stack.Screen
            name="NewGroup"
            component={NewGroup}
            options={{headerShown: false, gestureEnabled: false}}
          />
          <Stack.Screen
            name="BroadcastMessage"
            component={BroadcastMessage}
            options={{headerShown: false, gestureEnabled: false}}
          />
          <Stack.Screen
            name="Message"
            component={Message}
            options={{headerShown: false, gestureEnabled: false}}
          />
        </Stack.Navigator>
      </NavigationContainer>
      <FlashMessage position="top" />
    </>
  );
}

function TabNav() {
  return (
    <Tab.Navigator
      initialRouteName={'Search'}
      backBehavior={'none'}
      tabBarOptions={{
        style: {
          backgroundColor: color.first,
          height: 60,
          paddingBottom: 5,
          paddingTop: 5,
        },
        labelStyle: {
          fontWeight: 'normal',
          fontSize: dimension.fontSize.font1,
        },
        activeTintColor: color.success,
        inactiveTintColor: color.second,
      }}>
      <Tab.Screen
        name="Chat"
        component={Chat}
        options={{
          title: 'Chat',
          tabBarIcon: ({focused, iconColor, iconSize}) => (
            <Icon
              color={focused ? color.success : color.second}
              source={images.icons.chat}
              size={20}
            />
          ),
        }}
      />
      <Tab.Screen
        name="Broadcast"
        component={Broadcast}
        options={{
          title: 'Broadcast',
          tabBarIcon: ({focused, iconColor, iconSize}) => (
            <Icon
              color={focused ? color.success : color.second}
              source={images.icons.broadcast}
              size={20}
            />
          ),
        }}
      />
      <Tab.Screen
        name="Setting"
        component={Setting}
        options={{
          title: 'Setting',
          tabBarIcon: ({focused, iconColor, iconSize}) => (
            <Icon
              color={focused ? color.success : color.second}
              source={images.icons.setting}
              size={20}
            />
          ),
        }}
      />
      <Tab.Screen
        name="Help"
        component={Help}
        options={{
          title: 'Help',
          tabBarIcon: ({focused, iconColor, iconSize}) => (
            <Icon
              color={focused ? color.success : color.second}
              source={images.icons.help}
              size={20}
            />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

export default Navigation;
