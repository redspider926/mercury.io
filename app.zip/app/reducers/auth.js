import * as actionTypes from '../actions/actionTypes';

const initialState = {
  isAuth: false,
};

const auth = (state = initialState, action = {}) => {
  switch (action.type) {
    case actionTypes.LOGIN:
      return {
        isAuth: true,
      };
    case actionTypes.REGISTER:
      return {
        isAuth: true,
      };
    case actionTypes.LOGOUT:
      return {
        isAuth: false,
      };
    default:
      return state;
  }
};

export default auth;
