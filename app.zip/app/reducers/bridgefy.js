import * as actionTypes from '../actions/actionTypes';

const initialState = {
  isStarted: false,
  id: '',
  name: '',
  refreshKey: '',
};

const bridgefy = (state = initialState, action = {}) => {
  switch (action.type) {
    case actionTypes.BRIDGEFY_START:
      return {
        isStarted: true,
        id: action.payload.id,
        name: action.payload.name,
        refreshKey: '',
      };
    case actionTypes.BRIDGEFY_STOP:
      return {
        isStarted: false,
        id: '',
        name: '',
        refreshKey: '',
      };

    case actionTypes.MESSAGE_REFRESH:
      return {
        isStarted: state.isStarted,
        id: state.id,
        name: state.name,
        refreshKey: action.payload,
      };

    default:
      return state;
  }
};

export default bridgefy;
