import {combineReducers} from 'redux';

import auth from './auth';
import bridgefy from './bridgefy';
import user from './user';
import message from './message';
import setting from './setting';

export default combineReducers({auth, bridgefy, message, setting, user});
