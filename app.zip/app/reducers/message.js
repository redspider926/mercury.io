import * as actionTypes from '../actions/actionTypes';

const initialState = [];
const messageRead = (messages, chatId) => {
  messages.forEach((message) => {
    if (message.content.id === chatId) {
      message.content.state = 1;
    }
  });
  return messages;
};

const messageEdit = (messages, messageId, text) => {
  messages.forEach((message) => {
    if (JSON.parse(message.content.message)._id === messageId) {
      var newMessage = JSON.parse(message.content.message);
      newMessage.text = text;
      newMessage.sent = true;
      message.content.message = JSON.stringify(newMessage);
    }
  });
  return messages;
};

const messageDelete = (messages, messageId) => {
  const _messages = messages.filter(
    (_message) => JSON.parse(_message.content.message)._id !== messageId,
  );
  return _messages;
};

const message = (state = initialState, action = {}) => {
  switch (action.type) {
    case actionTypes.MESSAGE_ADD:
      return [action.payload, ...state];

    case actionTypes.MESSAGE_INIT:
      return [];

    case actionTypes.MESSAGE_READ:
      return messageRead(state, action.payload);

    case actionTypes.MESSAGE_EDIT:
      return messageEdit(state, action.payload.messageId, action.payload.text);

    case actionTypes.MESSAGE_DELETE:
      return messageDelete(state, action.payload);

    default:
      return state;
  }
};

export default message;
