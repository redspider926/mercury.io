import * as actionTypes from '../actions/actionTypes';

const initialState = {};

const setting = (state = initialState, action = {}) => {
  switch (action.type) {
    case actionTypes.SETTING_SAVE:
      return {
        ...action.payload,
      };
    default:
      return state;
  }
};

export default setting;
