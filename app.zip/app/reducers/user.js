import * as actionTypes from '../actions/actionTypes';

const initialState = {
  chats: [],
  devices: [],
};

// device{
//   id: String,
//   deviceName: String,
//   userName:String,
// }

// chat{
//   id: [],
//   name:String,
//   users: [{
//     id: String,
//     deviceName: String,
//     userName: String,
//     state: [Number](1: invitation_sender, 2: invitation_receiver, 3: accepted)
//   }]
// }
const chatAccept = (chats, payload) => {
  chats.forEach((chat) => {
    if (chat.id === payload.id) {
      chat.users.forEach((user) => {
        if (user.id === payload.userId) {
          user.state = 1;
        }
      });
    }
  });
  console.log(chats);
  return chats;
};

const user = (state = initialState, action = {}) => {
  switch (action.type) {
    //device reducers
    case actionTypes.DEVICE_CONNECT:
      return {
        chats: state.chats,
        devices: [
          ...state.devices.filter(
            (device) => device.id !== action.payload.userId,
          ),
          {
            id: action.payload.userId,
            name: action.payload.userId,
          },
        ],
      };
    case actionTypes.DEVICE_DISCONNECT:
      return {
        chats: state.chats,
        devices: state.devices.filter(
          (device) => device.id !== action.payload.userId,
        ),
      };
    case actionTypes.DEVICE_INIT:
      return {
        chats: state.chats,
        devices: [],
      };

    //chat reducers
    case actionTypes.CHAT_CREATE:
      return {
        chats: [...state.chats, action.payload],
        devices: state.devices,
      };

    case actionTypes.CHAT_ACCEPT:
      return {
        chats: chatAccept(state.chats, action.payload),
        devices: state.devices,
      };

    default:
      return state;
  }
};

export default user;
