import React, {useState} from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';

import * as images from '@config/images';
import * as color from '@config/color';
import shareStyle from '@config/style';
import styles from './style';

const Bluetooth = (props) => {
  const [bluetoothState, setBluetoothState] = useState(false);
  return (
    <>
      <View style={styles.container}>
        <TouchableOpacity
          style={[
            styles.button,
            bluetoothState ? styles.isActive : styles.isNotActive,
          ]}
          activeOpacity={1}
          onPress={() => {
            setBluetoothState(!bluetoothState);
          }}>
          <Image style={styles.buttonImage} source={images.images.bluetooth} />
        </TouchableOpacity>
        <View style={styles.space} />
        <Text style={styles.text}>
          Make sure your Bluetooth is turnd on you're in a close range to your
          Smart Lock Devices
        </Text>
        <TouchableOpacity
          style={[styles.buttonStart, shareStyle.shadow]}
          onPress={() => props.navigation.navigate('TabNav')}>
          <Text style={styles.buttonStartText}>Get Started</Text>
        </TouchableOpacity>
      </View>
    </>
  );
};

export default Bluetooth;
