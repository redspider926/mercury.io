import {StyleSheet} from 'react-native';
import * as dimension from '@config/dimension';
import * as color from '@config/color';

export default StyleSheet.create({
  container: {
    width: '100%',
    height: '100%',
    backgroundColor: color.first,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: dimension.size.size_normal,
  },

  isActive: {
    backgroundColor: color.success,
  },

  isNotActive: {
    backgroundColor: color.black,
  },

  button: {
    width: 160,
    height: 160,
    backgroundColor: color.gray,
    borderRadius: 150,
    alignItems: 'center',
    justifyContent: 'center',
  },

  buttonImage: {
    width: 200,
    height: 200,
  },

  text: {
    color: color.second,
    fontSize: dimension.fontSize.font1,
    textAlign: 'center',
    marginTop: dimension.size.size_normal,
    marginBottom: dimension.size.size_normal,
  },

  buttonStart: {
    backgroundColor: color.second,
    width: '100%',
    height: dimension.size.size_normal,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: dimension.size.size1,
  },

  buttonStartText: {
    color: color.main,
    fontSize: dimension.fontSize.font2,
    fontWeight: 'bold',
  },
});
