import React, {useState} from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
// import * as Progress from 'react-native-progress';

import * as images from '@config/images';
import styles from './style';
import shareStyles from '@config/style';

const Broadcast = (props) => {
  return (
    <>
      <View style={[shareStyles.root, styles.root]}>
        {/* <Progress.Circle size={30} indeterminate={true} /> */}
        <View style={styles.view1}>
          <Text style={styles.title}>BROADCAST</Text>
        </View>
        <View style={styles.view2}>
          <Image style={styles.image} source={images.images.broadcast} />
          <Text style={styles.text}>You can chat with people near you.</Text>
          <TouchableOpacity
            style={styles.buttonStart}
            onPress={() => props.navigation.navigate('BroadcastMessage')}>
            <Text style={styles.textButton}>Start Broadcast mode</Text>
          </TouchableOpacity>
        </View>
      </View>
    </>
  );
};

export default Broadcast;
