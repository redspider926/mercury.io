import React, {useState, useEffect} from 'react';
import {Alert, View, Text, TouchableOpacity, Image} from 'react-native';
import {GiftedChat, Bubble, Send} from 'react-native-gifted-chat';

import {UserActions, MessageActions} from '@actions';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';

import RNBridgefy from 'react-native-bridgefy-sdk';

import Icon from '@components/Icon';

import * as images from '@config/images';
import * as color from '@config/color';
import styles from './style';
import shareStyles from '@config/style';

import {launchCamera, launchImageLibrary} from 'react-native-image-picker';

const BroadcastMessage = (props) => {
  const myId = props.bridgefy.id;
  const isStarted = props.bridgefy.isStarted;

  const [imageSource, setImageSource] = useState(null);
  const [messageText, setMessageText] = useState('');

  const [editState, setEditState] = useState(false);
  const [editMessageId, setEditMessageId] = useState('');

  function selectImage(evt) {
    let options = {
      title: 'You can choose one image',
      maxWidth: 256,
      maxHeight: 256,
      noData: true,
      mediaType: 'photo',
      storageOptions: {
        skipBackup: true,
      },
      includeBase64: true,
    };

    launchImageLibrary(options, (response) => {
      if (response.didCancel) {
        console.log('User cancelled photo picker');
        Alert.alert('You did not select any image');
      } else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      } else if (response.customButton) {
        console.log('User tapped custom button: ', response.customButton);
      } else {
        let source = {base64: response.base64};
        console.log(source.base64);
        setImageSource(`data:image/gif;base64,${source.base64}`);
      }
    });
  }

  const onEditCancel = () => {
    setEditState(false);
    setEditMessageId('');
    setMessageText('');
  };

  const onEdit = () => {
    sendMessageEdit(editMessageId, messageText);
    props.messageActions.messageEdit(editMessageId, messageText);
    setEditState(false);
  };

  const onSend = (messages) => {
    if (!isStarted) {
      Alert.alert('You are disconnected with your friend.');
      return false;
    }

    messages[0].image = imageSource;

    var message = {
      content: {
        message: JSON.stringify(messages[0]),
        type: 'MESSAGE',
        id: 'broadcast',
        state: 0,
      },
    };
    RNBridgefy.sendBroadcastMessage(message);

    props.messageActions.messageAdd({
      content: {
        message: JSON.stringify(messages[0]),
        type: 'MESSAGE',
        id: 'broadcast',
        state: 1,
      },
    });

    setImageSource(null);
  };

  const setMessages = (_messages) => {
    const messages = _messages.filter(
      (message) => message.content.id === 'broadcast',
    );
    return messages.map((message) => {
      return JSON.parse(message.content.message);
    });
  };

  const sendMessageDelete = (messageId) => {
    var messageDeleteInfo = {
      messageId: messageId,
    };
    var message = {
      content: {
        message: JSON.stringify(messageDeleteInfo),
        type: 'MESSAGE_DELETE',
      },
    };

    RNBridgefy.sendBroadcastMessage(message);
  };

  const sendMessageEdit = (messageId, text) => {
    var messageEditInfo = {
      messageId: messageId,
      text: text,
    };
    var message = {
      content: {
        message: JSON.stringify(messageEditInfo),
        type: 'MESSAGE_EDIT',
      },
    };

    RNBridgefy.sendBroadcastMessage(message);
  };

  return (
    <>
      <View style={styles.header}>
        <TouchableOpacity
          style={shareStyles.backButton}
          onPress={() => props.navigation.goBack()}>
          <Icon source={images.icons.back} color={color.second} size={20} />
        </TouchableOpacity>
        <Text style={styles.title}>BROADCAST MODE</Text>
      </View>
      <GiftedChat
        scrollToBottom={true} //scrollToBottomButton enable
        text={messageText}
        onInputTextChanged={(text) => setMessageText(text)}
        messages={setMessages(props.message)}
        onSend={(_messages) => {
          if (editState) {
            onEdit();
          } else {
            onSend(_messages);
          }
        }}
        user={{
          _id: myId,
          name: props.bridgefy.name,
        }}
        // text={text}
        // onInputTextChanged={(_text) => setText(_text)}
        alwaysShowSend={imageSource === null ? false : true}
        renderSend={(sendButtonProps) => {
          return (
            <Send {...sendButtonProps}>
              <View
                style={{
                  height: '100%',
                  width: 50,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                {editState ? (
                  <Icon
                    source={images.icons.edit}
                    color={color.first}
                    size={25}
                  />
                ) : (
                  <Icon
                    source={images.icons.send}
                    color={color.first}
                    size={25}
                  />
                )}
              </View>
            </Send>
          );
        }}
        renderChatFooter={() => {
          return (
            <>
              {imageSource === null ? (
                <></>
              ) : (
                <View style={{width: '100%', backgroundColor: color.gray}}>
                  <View style={{width: 120, height: 120}}>
                    <Image
                      style={{
                        width: 100,
                        height: 100,
                        margin: 10,
                      }}
                      source={{uri: imageSource}}
                    />
                    <TouchableOpacity
                      onPress={() => {
                        setImageSource(null);
                      }}
                      style={{
                        position: 'absolute',
                        top: 0,
                        right: 0,
                        width: 20,
                        height: 20,
                        alignItems: 'center',
                        justifyContent: 'center',
                        borderRadius: 10,
                        backgroundColor: color.second,
                        elevation: 10,
                      }}>
                      <Icon
                        source={images.icons.close}
                        color={color.first}
                        size={12}
                      />
                    </TouchableOpacity>
                  </View>
                </View>
              )}
            </>
          );
        }}
        renderMessageImage={(renderMessageImageProps) => {
          return (
            <View
              style={
                {
                  // borderRadius: 15,
                }
              }>
              <Image
                {...renderMessageImageProps.imageProps}
                style={{
                  width: 200,
                  height: 200,
                  borderTopLeftRadius: 15,
                  borderTopRightRadius: 15,
                  resizeMode: 'cover',
                }}
                source={{
                  uri: renderMessageImageProps.currentMessage.image,
                }}
              />
            </View>
          );
        }}
        renderActions={() => (
          <View
            style={{
              width: 50,
              height: '100%',
              alignItems: 'center',
              justifyContent: 'flex-end',
              paddingBottom: 12,
            }}>
            {editState ? (
              <TouchableOpacity onPress={onEditCancel}>
                <Icon
                  source={images.icons.close}
                  color={color.first}
                  size={20}
                />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity onPress={selectImage}>
                <Icon
                  source={images.icons.attach}
                  color={color.first}
                  size={20}
                />
              </TouchableOpacity>
            )}
          </View>
        )}
        renderBubble={(bubbleProps) => {
          return (
            <Bubble
              {...bubbleProps}
              textStyle={{
                right: {
                  color: 'white',
                },
              }}
              wrapperStyle={{
                left: {
                  backgroundColor: '#addbe6',
                },
              }}
            />
          );
        }}
        onLongPress={(context, message) => {
          console.log(context, message);

          var options = ['Edit Message', 'Delete Message', 'Cancel'];
          if (message.user._id !== myId) {
            return false;
          }
          var editButtonIndex = 0;
          if (message.text === '') {
            options = ['Delete Message', 'Cancel']; //can't edit only image
            editButtonIndex = -1;
          }

          if (!isStarted) {
            Alert.alert(
              'You can edit or delete chat when you are disconnected with your friends.',
            );
            return false;
          }

          const deleteButtonIndex = options.length - 2;
          const cancelButtonIndex = options.length - 1;
          context.actionSheet().showActionSheetWithOptions(
            {
              options,
              cancelButtonIndex,
            },
            (buttonIndex) => {
              switch (buttonIndex) {
                case editButtonIndex:
                  setMessageText(message.text);
                  setEditState(true);
                  setEditMessageId(message._id);
                  break;
                case deleteButtonIndex:
                  sendMessageDelete(message._id, message.user._id);
                  props.messageActions.messageDelete(message._id);
                  break;
                case cancelButtonIndex:
                  break;
                default:
                  break;
              }
            },
          );
        }}
      />
    </>
  );
};

const mapStateToProps = (state) => {
  return {user: state.user, bridgefy: state.bridgefy, message: state.message};
};

const mapDispatchToProps = (dispatch) => {
  return {
    userActions: bindActionCreators(UserActions, dispatch),
    messageActions: bindActionCreators(MessageActions, dispatch),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(BroadcastMessage);
