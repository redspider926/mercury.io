import {StyleSheet} from 'react-native';
import * as dimension from '@config/dimension';
import * as color from '@config/color';

export default StyleSheet.create({
  connected: {
    backgroundColor: 'rgba(22,255,22,.3)',
  },
  connectedText: {
    color: 'green',
    textAlign: 'center',
  },
  disconnected: {
    backgroundColor: 'rgba(255,22,22,.3)',
  },
  disconnectedText: {
    color: 'red',
    textAlign: 'center',
  },
  header: {
    backgroundColor: color.first,
    width: '100%',
    height: dimension.size.size_header,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    color: color.second,
    fontSize: dimension.fontSize.font2,
  },
});
