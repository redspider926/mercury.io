import React, {useEffect, useState} from 'react';
import {View, Text, TouchableOpacity, FlatList} from 'react-native';
// import * as Progress from 'react-native-progress';
import Icon from '@components/Icon';
import Contact from '@components/Contact';

import * as images from '@config/images';
import * as color from '@config/color';
import styles from './style';
import shareStyles from '@config/style';

import {UserActions} from '@actions';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';

const Chat = (props) => {
  const messages = props.message;
  const [refreshKey, setRefreshKey] = useState('');

  useEffect(() => {
    const refresh = props.navigation.addListener('focus', () => {
      setRefreshKey(makeRefreshKey());
    });

    // Return the function to unsubscribe from the event so it gets removed on unmount
    return refresh;
  }, []);

  //notification refresh when screen is focused
  const makeRefreshKey = () => {
    var key = '';
    var possible =
      'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

    for (var i = 0; i < 5; i++) {
      key += possible.charAt(Math.floor(Math.random() * possible.length));
    }

    return key;
  };

  const getFinalChat = (chatId) => {
    var messagesInChat = messages.filter(
      (message) => message.content.id === chatId,
    );
    messagesInChat = messagesInChat.map((messageInChat) => {
      return JSON.parse(messageInChat.content.message);
    });
    if (messagesInChat.length === 0) {
      return 'new chat';
    }
    if (messagesInChat[0].image !== null) {
      console.log(messagesInChat[0].image);
      return 'image';
    }

    var finalMessage = messagesInChat[0].text;

    if (finalMessage.length > 25) {
      finalMessage = finalMessage.slice(0, 25) + '...';
    }

    console.log(finalMessage);
    return finalMessage;
  };

  const getUnreadMessageCount = (chatId) => {
    const messages = props.message.filter(
      (message) => message.content.id === chatId && message.content.state === 0,
    );
    return messages.length;
  };

  const setName = (name) => {
    return name.length > 15 ? name.slice(0, 15) + '...' : name;
  };

  const renderItem = ({item}) => {
    return (
      <Contact
        id={item.id}
        name={setName(item.name)}
        users={item.users}
        finalChat={getFinalChat(item.id)}
        notification={getUnreadMessageCount(item.id)}
        isConnected={checkIsConnected(item.users)}
        navigation={props.navigation}
      />
    );
  };

  const checkIsConnected = (users) => {
    var userIdArray = users.map((user) => {
      return user.id;
    });
    const userIdArrayExceptMe = userIdArray.filter(
      (userId) => userId !== props.bridgefy.id,
    );
    const deviceIdArray = props.user.devices.map((device) => {
      return device.id;
    });
    const isConnected = userIdArrayExceptMe.every((userId) =>
      deviceIdArray.includes(userId),
    );
    return isConnected;
  };

  const chats = props.user.chats;

  return (
    <>
      <View style={[shareStyles.root, styles.root]} key={refreshKey}>
        <View style={styles.view1}>
          <Text style={styles.title}>CHAT</Text>
        </View>
        <View style={styles.view2}>
          {chats.length === 0 ? (
            <View style={styles.emptyView}>
              <Text>Please start chat with your friends</Text>
            </View>
          ) : (
            <FlatList
              style={styles.flat}
              data={chats}
              renderItem={renderItem}
              keyExtractor={(item) => item.id}
            />
          )}

          <TouchableOpacity
            style={styles.addButton}
            onPress={() => props.navigation.navigate('NewContact')}>
            <Icon source={images.icons.add} color={color.second} size={30} />
          </TouchableOpacity>
        </View>
      </View>
    </>
  );
};

const mapStateToProps = (state) => {
  return {user: state.user, bridgefy: state.bridgefy, message: state.message};
};

const mapDispatchToProps = (dispatch) => {
  return {actions: bindActionCreators(UserActions, dispatch)};
};

export default connect(mapStateToProps, mapDispatchToProps)(Chat);
