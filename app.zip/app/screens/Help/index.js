import React, {useState} from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
// import * as Progress from 'react-native-progress';
import Icon from '@components/Icon';
import Input from '@components/Input';

import * as images from '@config/images';
import * as color from '@config/color';
import styles from './style';
import shareStyles from '@config/style';

const Help = (props) => {
  return (
    <>
      <View style={[shareStyles.root, styles.root]}>
        {/* <Progress.Circle size={30} indeterminate={true} /> */}
        <View style={styles.view1}>
          <Text style={styles.title}>HELP</Text>
        </View>
        <View style={styles.view2}>
          <Text style={styles.text}>
            The Bridgefy app works thanks to the Bridgefy SDK, which is
            basically software that makes any mobile app work without the
            Internet. Instead of using Internet or phone services (like SMS),
            the Bridgefy technology runs on Bluetooth Low-Energy. This means
            that it connects devices 100% without Internet, and can cover large
            distances. To learn more about the specific ways the Bridgefy App
            works, please read our blog article How To Use The Bridgefy Offline
            Messaging App. You’ll be able to see illustrated examples of how the
            Bridgefy app has helped millions of people connect during concerts,
            festivals, sports events, natural disasters, and more!
          </Text>
        </View>
      </View>
    </>
  );
};

export default Help;
