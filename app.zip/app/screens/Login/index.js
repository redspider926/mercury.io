import React, {useState} from 'react';
import {View, Text, TouchableOpacity, Image} from 'react-native';
import Input from '@components/Input';
import Icon from '@components/Icon';

import * as images from '@config/images';
import * as color from '@config/color';
import styles from './style';
import shareStyles from '@config/style';

import {AuthActions} from '@actions';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';

const Login = (props) => {
  return (
    <>
      <View style={[shareStyles.root, styles.root]}>
        <View style={styles.container}>
          <Image source={images.images.logo} style={styles.logo} />
          <View style={styles.space2} />
          <Text style={styles.title}>Welcome to Mercury</Text>

          <View style={styles.space2} />
          <View style={styles.socialView}>
            <TouchableOpacity style={[styles.socialItem, shareStyles.shadow]}>
              <Icon
                source={images.icons.instagram}
                size={20}
                color={color.first}
              />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.socialItem, shareStyles.shadow]}>
              <Icon
                source={images.icons.soundcloud}
                size={30}
                color={color.first}
              />
            </TouchableOpacity>
          </View>
          <View style={styles.space2} />

          <Input placeholder="" type="email" title="Email" />
          <Input placeholder="" type="password" title="Password" />

          <View style={styles.view1}>
            <TouchableOpacity>
              <Text style={styles.text}>Forget Password?</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.authButton, shareStyles.shadow]}
              onPress={() => {
                props.actions.login('');
                // console.log(props);
                props.navigation.navigate('Permissions');
              }}>
              <Text style={styles.authButtonText}>Sign in</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.space2} />
          <TouchableOpacity
            onPress={() => {
              props.navigation.navigate('Register');
            }}>
            <Text style={styles.text}>Do you want to create account?</Text>
          </TouchableOpacity>
        </View>
      </View>
    </>
  );
};

const mapStateToProps = (state) => {
  return {auth: state.auth};
};

const mapDispatchToProps = (dispatch) => {
  return {actions: bindActionCreators(AuthActions, dispatch)};
};

export default connect(mapStateToProps, mapDispatchToProps)(Login);
