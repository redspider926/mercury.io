import {StyleSheet} from 'react-native';
import * as dimension from '@config/dimension';
import * as color from '@config/color';

export default StyleSheet.create({
  container: {
    backgroundColor: color.first,
    width: '100%',
    height: '100%',
    padding: dimension.size.size_normal,
    alignItems: 'center',
  },

  root: {backgroundColor: color.second},

  logo: {
    width: 100,
    height: 100,
  },

  authButton: {
    backgroundColor: color.second,
    width: '40%',
    height: dimension.size.size_normal,
    borderRadius: dimension.size.size1,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },

  authButtonText: {
    fontSize: dimension.fontSize.font2,
    color: color.first,
    fontWeight: 'bold',
  },

  title: {
    fontSize: dimension.fontSize.font3,
    fontWeight: 'bold',
    color: color.second,
  },

  view1: {
    width: '100%',
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 20,
  },

  space2: {
    flex: 1,
  },

  text: {
    color: color.second,
    textDecorationLine: 'underline',
    fontSize: dimension.fontSize.font1,
  },

  socialItem: {
    width: dimension.size.size_normal + 10,
    height: dimension.size.size_normal + 10,
    borderRadius: 30,
    backgroundColor: color.second,
    alignItems: 'center',
    justifyContent: 'center',
  },

  socialView: {
    display: 'flex',
    flexDirection: 'row',
    width: '50%',
    justifyContent: 'space-around',
  },
});
