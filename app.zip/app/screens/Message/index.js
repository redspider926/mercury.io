import React, {useEffect, useState} from 'react';
import {View, Text, TouchableOpacity, Alert, Image} from 'react-native';
import {GiftedChat, Bubble, Send} from 'react-native-gifted-chat';
import Icon from '@components/Icon';

import * as images from '@config/images';
import * as color from '@config/color';
import styles from './style';
import shareStyles from '@config/style';

import RNBridgefy from 'react-native-bridgefy-sdk';

import {UserActions, MessageActions} from '@actions';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';

import {launchCamera, launchImageLibrary} from 'react-native-image-picker';

const Message = (props) => {
  console.log('navigation parameter params----', props.route.params);

  const [imageSource, setImageSource] = useState(null);
  const [messageText, setMessageText] = useState('');

  const chatId = props.route.params.id;
  const refreshKey = props.bridgefy.refreshKey;

  const [editState, setEditState] = useState(false);
  const [editMessageId, setEditMessageId] = useState('');

  useEffect(() => {
    props.messageActions.messageRead(props.route.params.id);
    return function cleanup() {
      props.messageActions.messageRead(props.route.params.id);
    };
  });

  function selectImage(evt) {
    let options = {
      title: 'You can choose one image',
      maxWidth: 256,
      maxHeight: 256,
      noData: true,
      mediaType: 'photo',
      storageOptions: {
        skipBackup: true,
      },
      includeBase64: true,
    };

    launchImageLibrary(options, (response) => {
      if (response.didCancel) {
        console.log('User cancelled photo picker');
        Alert.alert('You did not select any image');
      } else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      } else if (response.customButton) {
        console.log('User tapped custom button: ', response.customButton);
      } else {
        let source = {base64: response.base64};
        setImageSource(`data:image/gif;base64,${source.base64}`);
      }
    });
  }

  const checkIsConnected = () => {
    var userIdArray = users.map((user) => {
      return user.id;
    });
    const userIdArrayExceptMe = userIdArray.filter(
      (userId) => userId !== props.bridgefy.id,
    );
    const deviceIdArray = props.user.devices.map((device) => {
      return device.id;
    });
    const isConnected = userIdArrayExceptMe.every((userId) =>
      deviceIdArray.includes(userId),
    );
    return isConnected;
  };

  const myId = props.bridgefy.id;
  const users = props.route.params.users;
  const chatName = props.route.params.name;
  const isConnected = checkIsConnected();

  const onEditCancel = () => {
    setEditState(false);
    setEditMessageId('');
    setMessageText('');
  };

  const onEdit = () => {
    sendMessageEdit(editMessageId, messageText);
    props.messageActions.messageEdit(editMessageId, messageText);
    setEditState(false);
  };

  const onSend = (messages) => {
    if (!isConnected) {
      Alert.alert('You are disconnected with your friend.');
      return false;
    }

    messages[0].image = imageSource;

    users.map((user) => {
      if (user.id !== myId) {
        var message = {
          content: {
            message: JSON.stringify(messages[0]),
            type: 'MESSAGE',
            id: chatId,
            state: 0, //read, unread
          },
          receiver_id: user.id,
          // dataLocalURI: dataUri,
        };
        RNBridgefy.sendMessage(message);
      }
    });

    props.messageActions.messageAdd({
      content: {
        message: JSON.stringify(messages[0]),
        type: 'MESSAGE',
        id: chatId,
        state: 1, //read, unread
      },
    });

    setImageSource(null);
  };

  const checkState = () => {
    var a = false;
    var b = false;
    var c = false;
    users.forEach((user) => {
      if (user.state === 0 && user.id === myId) {
        c = true;
      }
      if (user.state === 1 && user.id === myId) {
        a = true; //my state is true
      }
      if (user.state === 1 && user.id !== myId) {
        b = true; //friend's state is true
      }
    });
    if (c === true) {
      return 1;
    }
    if (a === true && b === true) {
      return 3; //chat enable
    }
    if (a === true && b === false) {
      return 2; //wait that other accept
    }
  };

  const onPressAccept = () => {
    if (!isConnected) {
      Alert.alert(
        "You can't accept chat when you are disconnect with chat friends",
      );
      return false;
    }
    users.forEach((user) => {
      if (user.id !== myId) {
        var message = {
          content: {
            message: JSON.stringify({
              id: chatId,
              userId: myId,
            }),
            type: 'ACCEPT',
          },
          receiver_id: user.id,
        };
        RNBridgefy.sendMessage(message);
      }
    });
    props.userActions.chatAccept({id: chatId, userId: myId});
  };

  const setMessages = (_messages) => {
    const messages = _messages.filter(
      (message) => message.content.id === chatId,
    );
    return messages.map((message) => {
      return JSON.parse(message.content.message);
    });
  };

  const sendMessageDelete = (messageId, receiver_id) => {
    var messageDeleteInfo = {
      messageId: messageId,
    };
    var message = {
      content: {
        message: JSON.stringify(messageDeleteInfo),
        type: 'MESSAGE_DELETE',
      },
      receiver_id: receiver_id,
    };

    RNBridgefy.sendBroadcastMessage(message);
  };

  const sendMessageEdit = (messageId, text, receiver_id) => {
    var messageEditInfo = {
      messageId: messageId,
      text: text,
    };
    var message = {
      content: {
        message: JSON.stringify(messageEditInfo),
        type: 'MESSAGE_EDIT',
      },
      receiver_id: receiver_id,
    };

    RNBridgefy.sendBroadcastMessage(message);
  };

  return (
    <>
      <View style={styles.header}>
        <TouchableOpacity
          style={shareStyles.backButton}
          onPress={() => props.navigation.goBack()}>
          <Icon source={images.icons.back} color={color.second} size={20} />
        </TouchableOpacity>
        <Text style={styles.name}>{chatName}</Text>
        <View style={styles.stateGroup}>
          <View
            style={[
              styles.state,
              isConnected ? styles.connected : styles.disconnected,
            ]}
          />
          <Text style={styles.stateText}>
            {isConnected ? 'connected' : 'disconnected'}
          </Text>
        </View>
      </View>
      {checkState() === 2 ? (
        <View style={styles.lobbyView}>
          <View style={styles.frame}>
            <Text style={styles.frameText}>Wait acceptation...</Text>
            <Icon
              source={images.icons.password}
              color={color.second}
              size={30}
            />
          </View>
        </View>
      ) : checkState() === 1 ? (
        <View style={styles.lobbyView}>
          <View style={styles.frame}>
            <Text style={styles.frameText}>Hello. Can I help you?</Text>
            <TouchableOpacity
              style={styles.button}
              onPress={() => onPressAccept()}
              disabled={!isConnected}>
              <Text style={styles.buttonText}>Accept</Text>
            </TouchableOpacity>
          </View>
        </View>
      ) : (
        <GiftedChat
          key={refreshKey}
          text={messageText}
          onInputTextChanged={(text) => setMessageText(text)}
          messages={setMessages(props.message)}
          onSend={(_messages) => {
            if (editState) {
              onEdit();
            } else {
              onSend(_messages);
            }
          }}
          user={{
            _id: myId,
            name: props.bridgefy.name,
          }}
          alwaysShowSend={imageSource === null ? false : true}
          renderSend={(sendButtonProps) => {
            return (
              <Send {...sendButtonProps}>
                <View
                  style={{
                    height: '100%',
                    width: 50,
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                  {editState ? (
                    <Icon
                      source={images.icons.edit}
                      color={color.first}
                      size={25}
                    />
                  ) : (
                    <Icon
                      source={images.icons.send}
                      color={color.first}
                      size={25}
                    />
                  )}
                </View>
              </Send>
            );
          }}
          renderChatFooter={() => {
            return (
              <>
                {imageSource === null ? (
                  <></>
                ) : (
                  <View style={{width: '100%', backgroundColor: color.gray}}>
                    <View style={{width: 120, height: 120}}>
                      <Image
                        style={{
                          width: 100,
                          height: 100,
                          margin: 10,
                        }}
                        source={{uri: imageSource}}
                      />
                      <TouchableOpacity
                        onPress={() => {
                          setImageSource(null);
                        }}
                        style={{
                          position: 'absolute',
                          top: 0,
                          right: 0,
                          width: 20,
                          height: 20,
                          alignItems: 'center',
                          justifyContent: 'center',
                          borderRadius: 10,
                          backgroundColor: color.second,
                          elevation: 10,
                        }}>
                        <Icon
                          source={images.icons.close}
                          color={color.first}
                          size={12}
                        />
                      </TouchableOpacity>
                    </View>
                  </View>
                )}
              </>
            );
          }}
          renderMessageImage={(props) => (
            <View
              style={{
                // borderRadius: 15,
                padding: 2,
              }}>
              <Image
                resizeMode="contain"
                style={{
                  width: 200,
                  height: 200,
                  // borderRadius: 15,
                  borderTopLeftRadius: 15,
                  borderTopRightRadius: 15,
                  resizeMode: 'cover',
                }}
                source={{uri: props.currentMessage.image}}
              />
            </View>
          )}
          renderActions={() => (
            <View
              style={{
                width: 50,
                height: '100%',
                alignItems: 'center',
                justifyContent: 'flex-end',
                paddingBottom: 12,
              }}>
              {editState ? (
                <TouchableOpacity onPress={onEditCancel}>
                  <Icon
                    source={images.icons.close}
                    color={color.first}
                    size={20}
                  />
                </TouchableOpacity>
              ) : (
                <TouchableOpacity onPress={selectImage}>
                  <Icon
                    source={images.icons.attach}
                    color={color.first}
                    size={20}
                  />
                </TouchableOpacity>
              )}
            </View>
          )}
          renderBubble={(bubbleProps) => {
            return (
              <Bubble
                {...bubbleProps}
                textStyle={{
                  right: {
                    color: 'white',
                  },
                }}
                wrapperStyle={{
                  left: {
                    backgroundColor: '#add8e6',
                  },
                }}
              />
            );
          }}
          onLongPress={(context, message) => {
            // console.log(context, message);
            var options = ['Edit Message', 'Delete Message', 'Cancel'];
            if (message.user._id !== myId) {
              return false; //can't edit or delete friend's message
            }
            var editButtonIndex = 0;
            if (message.text === '') {
              options = ['Delete Message', 'Cancel']; //can't edit only image
              editButtonIndex = -1;
            }

            if (!isConnected) {
              Alert.alert(
                'You can edit or delete chat when you are disconnected with your friends.',
              );
              return false;
            }

            const deleteButtonIndex = options.length - 2;
            const cancelButtonIndex = options.length - 1;
            context.actionSheet().showActionSheetWithOptions(
              {
                options,
                cancelButtonIndex,
              },
              (buttonIndex) => {
                switch (buttonIndex) {
                  case editButtonIndex:
                    setMessageText(message.text);
                    setEditState(true);
                    setEditMessageId(message._id);
                    break;
                  case deleteButtonIndex:
                    sendMessageDelete(message._id, message.user._id);
                    props.messageActions.messageDelete(message._id);
                    break;
                  case cancelButtonIndex:
                    break;
                  default:
                    break;
                }
              },
            );
          }}
        />
      )}
    </>
  );
};

const mapStateToProps = (state) => {
  return {user: state.user, bridgefy: state.bridgefy, message: state.message};
};

const mapDispatchToProps = (dispatch) => {
  return {
    userActions: bindActionCreators(UserActions, dispatch),
    messageActions: bindActionCreators(MessageActions, dispatch),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Message);
