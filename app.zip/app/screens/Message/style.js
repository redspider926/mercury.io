import {StyleSheet} from 'react-native';
import * as color from '@config/color';
import * as dimension from '@config/dimension';

export default StyleSheet.create({
  header: {
    backgroundColor: color.first,
    height: dimension.size.size_header,
    width: '100%',
    justifyContent: 'center',
    paddingLeft: dimension.size.padding * 4,
  },

  state: {
    width: 10,
    height: 10,
    borderRadius: 10,
    marginRight: dimension.size.padding,
  },

  connected: {
    backgroundColor: color.success,
  },

  disconneced: {
    backgroundColor: color.gray,
  },

  name: {
    color: color.second,
    fontSize: dimension.fontSize.font2,
  },

  stateGroup: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
  },

  stateText: {
    color: color.second,
  },

  lobbyView: {
    flex: 1,
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    padding: dimension.size.padding,
    backgroundColor: color.gray,
  },

  button: {
    width: 150,
    height: dimension.size.size_normal,
    borderRadius: dimension.size.size1,
    backgroundColor: color.second,
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },

  buttonText: {
    color: color.first,
    fontSize: dimension.fontSize.font2,
  },

  frame: {
    width: '100%',
    height: 150,
    // borderRadius: dimension.size.padding,
    backgroundColor: color.first,
    borderWidth: 3,
    borderColor: color.first,
    padding: dimension.size.size3,
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  frameText: {
    color: color.second,
    fontSize: dimension.fontSize.font2,
  },
});
