import React, {useState} from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
// import * as Progress from 'react-native-progress';
import Icon from '@components/Icon';

import * as images from '@config/images';
import * as color from '@config/color';
import styles from './style';
import shareStyles from '@config/style';

const NewContact = (props) => {
  return (
    <>
      <View style={[shareStyles.root, styles.root]}>
        {/* <Progress.Circle size={30} indeterminate={true} /> */}
        <View style={styles.view1}>
          <TouchableOpacity
            style={shareStyles.backButton}
            onPress={() => props.navigation.goBack()}>
            <Icon source={images.icons.back} color={color.second} size={20} />
          </TouchableOpacity>
          <Text style={styles.title}>NEW CONTACT</Text>
        </View>
        <View style={styles.view2}>
          <TouchableOpacity
            style={styles.buttonCreate}
            onPress={() => props.navigation.navigate('NewGroup')}>
            <Icon source={images.icons.group} size={20} color={color.second} />
            <Text style={styles.textButton}>New Group Chat</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.buttonCreate}
            onPress={() => props.navigation.navigate('NewSecret')}>
            <Icon
              source={images.icons.password}
              size={20}
              color={color.second}
            />
            <Text style={styles.textButton}>New Secret Chat</Text>
          </TouchableOpacity>
        </View>
      </View>
    </>
  );
};

export default NewContact;
