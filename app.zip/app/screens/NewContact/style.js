import {StyleSheet} from 'react-native';
import * as dimension from '@config/dimension';
import * as color from '@config/color';

export default StyleSheet.create({
  root: {
    backgroundColor: color.first,
  },

  title: {
    fontSize: dimension.fontSize.font2,
    color: color.second,
  },

  text: {
    fontSize: dimension.fontSize.font2,
    color: color.first,
    marginTop: 50,
    marginBottom: 50,
  },

  image: {
    width: 200,
    height: 200,
    tintColor: color.gray,
  },

  view1: {
    height: dimension.size.size_header,
    width: '100%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },

  view2: {
    flex: 1,
    width: '100%',
    backgroundColor: color.second,
    // borderTopLeftRadius: dimension.size.size_normal,
    // borderTopRightRadius: dimension.size.size_normal,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: dimension.size.padding,
  },

  buttonCreate: {
    width: '100%',
    height: dimension.size.size_normal,
    borderRadius: dimension.size.size1,
    backgroundColor: color.first,
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
    marginTop: 20,
  },

  textButton: {
    color: color.second,
    fontSize: dimension.fontSize.font2,
    marginLeft: 10,
  },
});
