import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  Alert,
  TextInput,
  ActivityIndicator,
} from 'react-native';
// import * as Progress from 'react-native-progress';
import Input from '@components/Input';
import Device from '@components/Device';
import Icon from '@components/Icon';

import styles from './style';
import shareStyles from '@config/style';
import * as images from '@config/images';
import * as color from '@config/color';

import {UserActions, MessageActions} from '@actions';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';

import RNBridgefy from 'react-native-bridgefy-sdk';

const NewGroup = (props) => {
  useEffect(() => {
    // RNBridgefy.stop();
  });

  const [selectedFriendsInfo, setSelectedFriendsInfo] = useState([]);
  const [chatName, setChatName] = useState('');

  const renderItem = ({item}) => {
    return (
      <Device
        id={item.id}
        name={item.name}
        onPress={() => onPressItem(item)}
        style="check"
        isSelected={selectedFriendsInfo
          .map((friend) => {
            return friend.id;
          })
          .includes(item.id)}
      />
    );
  };

  const onPressItem = (item) => {
    var friendInfo = {
      id: item.id,
      name: item.name,
      state: 0,
    };

    if (
      selectedFriendsInfo.map((friend) => friend.id).includes(friendInfo.id)
    ) {
      setSelectedFriendsInfo(
        selectedFriendsInfo.filter(
          (friend) => JSON.stringify(friend) !== JSON.stringify(friendInfo),
        ),
      );
    } else {
      setSelectedFriendsInfo([...selectedFriendsInfo, friendInfo]);
    }
  };

  const myInfo = {
    id: props.bridgefy.id,
    name: props.bridgefy.name,
    state: 1,
  };

  const checkChatRepeat = (userIdNewArray, chats) => {
    const chatUserIdsArray = chats.map((chat) => {
      return chat.users
        .map((user) => {
          return user.id;
        })
        .sort();
    });
    console.log('chatUserIdArray', chatUserIdsArray);
    console.log('userIdNewArray', userIdNewArray);
    for (const a of chatUserIdsArray) {
      if (JSON.stringify(a) === JSON.stringify(userIdNewArray)) {
        return true;
      }
    }

    return false;
  };

  const onPressInvite = () => {
    if (
      checkChatRepeat(
        [
          ...selectedFriendsInfo.map((friend) => {
            return friend.id;
          }),
          myInfo.id,
        ].sort(),
        props.user.chats,
      )
    ) {
      Alert.alert('You already created same chat before.');
      return false;
    }
    const chatId = new Date() + props.bridgefy.id;
    const chatInfoForGroup = {
      id: chatId,
      name: chatName,
      users: [...selectedFriendsInfo, myInfo],
    };

    selectedFriendsInfo.forEach((friend) => {
      var message = {
        content: {
          message: JSON.stringify(chatInfoForGroup),
          type: 'INVITE',
        },
        receiver_id: friend.id,
      };

      RNBridgefy.sendMessage(message);
    });

    props.userActions.chatCreate(chatInfoForGroup);

    props.navigation.navigate('Chat');
  };

  return (
    <>
      <View style={[shareStyles.root, styles.root]}>
        <View style={styles.view1}>
          <TouchableOpacity
            style={shareStyles.backButton}
            onPress={() => props.navigation.goBack()}>
            <Icon source={images.icons.back} color={color.second} size={20} />
          </TouchableOpacity>
          <Text style={styles.title}>NEW GROUP CHAT</Text>
        </View>
        <View style={styles.view2}>
          {/* <Input type="search" /> */}
          <Text style={styles.small_title}>GROUP CHAT NAME</Text>
          <TextInput
            style={{
              width: '100%',
              height: 50,
              backgroundColor: color.gray,
              borderRadius: 10,
              paddingLeft: 10,
            }}
            placeholder="Type a group chat name..."
            text={chatName}
            onChangeText={(text) => setChatName(text)}
          />
          <View style={styles.line} />
          <Text style={styles.small_title}>DETECTED USERS</Text>
          {props.user.devices.length === 0 ? (
            <View style={styles.emptyView}>
              <ActivityIndicator size="large" color={color.first} />
            </View>
          ) : (
            <FlatList
              style={styles.flat}
              data={props.user.devices}
              renderItem={renderItem}
              keyExtractor={(item) => item.id}
            />
          )}
          {selectedFriendsInfo.length >= 2 && chatName.length > 0 ? (
            <TouchableOpacity
              style={styles.buttonInvite}
              onPress={() => onPressInvite()}>
              <Text style={styles.textButton}>Create Group</Text>
            </TouchableOpacity>
          ) : (
            <></>
          )}
        </View>
      </View>
    </>
  );
};

const mapStateToProps = (state) => {
  return {user: state.user, bridgefy: state.bridgefy};
};

const mapDispatchToProps = (dispatch) => {
  return {
    userActions: bindActionCreators(UserActions, dispatch),
    messageActions: bindActionCreators(MessageActions, dispatch),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(NewGroup);
