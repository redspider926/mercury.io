import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from 'react-native';
// import * as Progress from 'react-native-progress';
import Input from '@components/Input';
import Device from '@components/Device';
import Icon from '@components/Icon';

import styles from './style';
import shareStyles from '@config/style';
import * as images from '@config/images';
import * as color from '@config/color';

import {UserActions, MessageActions} from '@actions';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';

import RNBridgefy from 'react-native-bridgefy-sdk';

const NewSecret = (props) => {
  useEffect(() => {
    // RNBridgefy.stop();
  });

  const [selectedFriendInfo, setSelectedFriendInfo] = useState(null);

  const renderItem = ({item}) => {
    return (
      <Device
        id={item.id}
        name={item.name}
        onPress={() => onPressItem(item)}
        style="option"
        isSelected={JSON.stringify(selectedFriendInfo) === JSON.stringify(item)}
      />
    );
  };

  const onPressItem = (item) => {
    if (JSON.stringify(selectedFriendInfo) === JSON.stringify(item)) {
      setSelectedFriendInfo(null);
    } else {
      setSelectedFriendInfo(item);
    }
  };

  const myInfo = {
    id: props.bridgefy.id,
    name: props.bridgefy.name,
    state: 1,
  };

  const friendInfo = {
    ...selectedFriendInfo,
    state: 0,
  };
  console.log([friendInfo, myInfo]);

  const checkChatRepeat = (userIdNewArray, chats) => {
    const chatUserIdsArray = chats.map((chat) => {
      return chat.users
        .map((user) => {
          return user.id;
        })
        .sort();
    });
    console.log('chatUserIdArray', chatUserIdsArray);
    console.log('userIdNewArray', userIdNewArray);
    for (const a of chatUserIdsArray) {
      if (JSON.stringify(a) === JSON.stringify(userIdNewArray)) {
        return true;
      }
    }

    return false;
  };

  const onPressInvite = (friend) => {
    if (checkChatRepeat([friendInfo.id, myInfo.id].sort(), props.user.chats)) {
      console.log('kkkkkk');
      Alert.alert('You already created same chat before.');
      return false;
    }
    const chatId = new Date() + props.bridgefy.id;
    const chatInfoForOthers = {
      id: chatId,
      name: myInfo.name,
      users: [friendInfo, myInfo],
    };

    const chatInfoForMe = {
      id: chatId,
      name: friendInfo.name,
      users: [friendInfo, myInfo],
    };

    var message = {
      content: {
        message: JSON.stringify(chatInfoForOthers),
        type: 'INVITE',
      },
      receiver_id: friend.id,
    };

    console.log('message', message);

    RNBridgefy.sendMessage(message);
    props.userActions.chatCreate(chatInfoForMe);

    props.navigation.navigate('Chat');
  };

  return (
    <>
      <View style={[shareStyles.root, styles.root]}>
        <View style={styles.view1}>
          <TouchableOpacity
            style={shareStyles.backButton}
            onPress={() => props.navigation.goBack()}>
            <Icon source={images.icons.back} color={color.second} size={20} />
          </TouchableOpacity>
          <Text style={styles.title}>NEW SECRET CHAT</Text>
        </View>
        <View style={styles.view2}>
          <Text style={styles.small_title}>DETECTED USERS</Text>
          {props.user.devices.length === 0 ? (
            <View style={styles.emptyView}>
              <ActivityIndicator size="large" color={color.first} />
            </View>
          ) : (
            <FlatList
              style={styles.flat}
              data={props.user.devices}
              renderItem={renderItem}
              keyExtractor={(item) => item.id}
            />
          )}
          {selectedFriendInfo !== null ? (
            <TouchableOpacity
              style={styles.buttonInvite}
              onPress={() => onPressInvite(selectedFriendInfo)}>
              <Text style={styles.textButton}>Invite friend</Text>
            </TouchableOpacity>
          ) : (
            <></>
          )}
        </View>
      </View>
    </>
  );
};

const mapStateToProps = (state) => {
  return {user: state.user, bridgefy: state.bridgefy};
};

const mapDispatchToProps = (dispatch) => {
  return {
    userActions: bindActionCreators(UserActions, dispatch),
    messageActions: bindActionCreators(MessageActions, dispatch),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(NewSecret);
