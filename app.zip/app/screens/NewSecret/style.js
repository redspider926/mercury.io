import {StyleSheet} from 'react-native';
import * as dimension from '@config/dimension';
import * as color from '@config/color';

export default StyleSheet.create({
  root: {
    backgroundColor: color.first,
  },

  title: {
    fontSize: dimension.fontSize.font2,
    color: color.second,
  },

  text: {
    fontSize: dimension.fontSize.font2,
    color: color.first,
    marginTop: 50,
    marginBottom: 50,
  },

  image: {
    width: 200,
    height: 200,
    tintColor: color.gray,
  },

  view1: {
    height: dimension.size.size_header,
    width: '100%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },

  view2: {
    flex: 1,
    width: '100%',
    backgroundColor: color.second,
    // borderTopLeftRadius: dimension.size.size_normal,
    // borderTopRightRadius: dimension.size.size_normal,
    display: 'flex',
    // justifyContent: 'center',
    padding: dimension.size.padding,
  },

  buttonInvite: {
    width: '100%',
    height: dimension.size.size_normal,
    borderRadius: dimension.size.size1,
    backgroundColor: color.first,
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },

  buttonDisabled: {
    backgroundColor: color.gray,
  },

  buttonEnabled: {
    backgroundColor: color.first,
  },

  textButton: {
    color: color.second,
    fontSize: dimension.fontSize.font2,
    marginLeft: 10,
  },

  flat: {
    width: '100%',
    flex: 1,
    marginBottom: 20,
  },

  emptyView: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },

  small_title: {
    color: color.first,
    fontSize: dimension.fontSize.font1,
    marginBottom: 10,
    fontWeight: 'bold',
  },
});
