import React, {useState} from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';

import * as images from '@config/images';
import * as color from '@config/color';
import shareStyle from '@config/style';
import styles from './style';

const Permissions = (props) => {
  const [bluetoothState, setBluetoothState] = useState(false);
  const [locationState, setLocationState] = useState(false);
  return (
    <>
      <View style={styles.container}>
        <View style={styles.permissionGroup}>
          <TouchableOpacity
            style={[
              styles.permissionButton,
              bluetoothState ? styles.activeTrue : styles.activeFalse,
            ]}
            onPress={() => setBluetoothState(!bluetoothState)}>
            <Image style={styles.image} source={images.icons.bluetooth} />
          </TouchableOpacity>
          <View style={styles.view}>
            <Text style={styles.permissionName}>BLUETOOTH</Text>
            <Text style={styles.permissionContent}>
              Please make sure your bluetooth state make sure your bluetooth
              state make sure your bluetooth state
            </Text>
          </View>
        </View>
        <View style={styles.permissionGroup}>
          <TouchableOpacity
            style={[
              styles.permissionButton,
              locationState ? styles.activeTrue : styles.activeFalse,
            ]}
            onPress={() => setLocationState(!locationState)}>
            <Image style={styles.image} source={images.icons.location} />
          </TouchableOpacity>
          <View style={styles.view}>
            <Text style={styles.permissionName}>LOCATION</Text>
            <Text style={styles.permissionContent}>
              Please make sure your bluetooth state make sure your bluetooth
              state make sure your bluetooth state
            </Text>
          </View>
        </View>
        <View style={{height: 100}} />
        <TouchableOpacity
          style={styles.buttonStart}
          onPress={() => props.navigation.navigate('Progress')}>
          <Text style={styles.buttonStartText}>GET STARTED</Text>
        </TouchableOpacity>
      </View>
    </>
  );
};

export default Permissions;
