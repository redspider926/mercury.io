import {StyleSheet} from 'react-native';
import * as dimension from '@config/dimension';
import * as color from '@config/color';

export default StyleSheet.create({
  container: {
    width: '100%',
    height: '100%',
    backgroundColor: color.first,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: dimension.size.padding,
  },

  permissionGroup: {
    borderRadius: dimension.size.padding,
    borderColor: color.second,
    borderWidth: 2,
    width: '100%',
    height: 150,
    marginBottom: dimension.size.padding,
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    padding: dimension.size.padding,
  },

  permissionButton: {
    width: 60,
    height: 60,
    borderRadius: 50,
    marginRight: dimension.size.padding,
    alignItems: 'center',
    justifyContent: 'center',
  },

  permissionName: {
    color: color.second,
    fontWeight: 'bold',
    fontSize: dimension.fontSize.font3,
  },

  permissionContent: {
    color: color.second,
    fontSize: dimension.fontSize.font1,
  },

  buttonStart: {
    backgroundColor: color.second,
    width: '100%',
    height: dimension.size.size_normal,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: dimension.size.size1,
  },

  buttonStartText: {
    color: color.main,
    fontSize: dimension.fontSize.font2,
    fontWeight: 'bold',
  },

  image: {
    width: 55,
    height: 55,
    borderRadius: 40,
    tintColor: color.first,
  },

  view: {
    height: 100,
    flex: 1,
    justifyContent: 'space-between',
  },

  activeTrue: {
    backgroundColor: color.success,
  },

  activeFalse: {
    backgroundColor: color.black,
  },
});
