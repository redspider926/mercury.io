import React, {useState, useEffect} from 'react';
import {
  View,
  NativeEventEmitter,
  PermissionsAndroid,
  Platform,
  ActivityIndicator,
} from 'react-native';
import RNBridgefy from 'react-native-bridgefy-sdk';

// import styles from './style';
import styles from './style';
import * as images from '@config/images';
import * as color from '@config/color';

import {BridgefyActions, MessageActions, UserActions} from '@actions';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';

const BRDG_LICENSE_KEY = '9dfc32fc-3fd2-4ec4-bb7b-a35bf45722f4';

const bridgefyEmitter = new NativeEventEmitter(RNBridgefy);

const Progress = (props) => {
  var userId = '';
  // 458e22f8-b3c5-4888-80d6-76c1909caa31
  useEffect(() => {
    initListeners();
    initBrdg();

    return () => {
      if (props.bridgefy.isStarted) {
        RNBridgefy.stop();
      }
      clearListeners();
    };
  }, []);

  let clearListeners = () => {
    console.log('clear listeners');
    bridgefyEmitter.removeAllListeners('onMessageReceived');
    bridgefyEmitter.removeAllListeners('onBroadcastMessageReceived');
    bridgefyEmitter.removeAllListeners('onMessageFailed');
    bridgefyEmitter.removeAllListeners('onMessageSent');
    bridgefyEmitter.removeAllListeners('onMessageReceivedException');
    bridgefyEmitter.removeAllListeners('onStarted');
    bridgefyEmitter.removeAllListeners('onStartError');
    bridgefyEmitter.removeAllListeners('onStopped');
    bridgefyEmitter.removeAllListeners('onDeviceConnected');
    bridgefyEmitter.removeAllListeners('onDeviceLost');
    bridgefyEmitter.removeAllListeners('onEventOccurred');
  };

  let initListeners = () => {
    console.log('INITIATING THE BRDG RN LISTENERS');
    bridgefyEmitter.addListener('onMessageReceived', (message) => {
      console.log('onMessageReceived: ' + JSON.stringify(message));
      switch (message.content.type) {
        case 'INVITE':
          props.userActions.chatCreate(JSON.parse(message.content.message));
          break;
        case 'ACCEPT':
          props.userActions.chatAccept(JSON.parse(message.content.message));
          break;
        case 'MESSAGE':
          props.messageActions.messageAdd(message);
          break;
        case 'MESSAGE_EDIT':
          props.messageActions.messageEdit(
            JSON.parse(message.content.message).messageId,
            JSON.parse(message.content.message).text,
          );
          props.bridgefyActions.messageRefresh(message.uuid);
          break;
        case 'MESSAGE_DELETE':
          props.messageActions.messageDelete(
            JSON.parse(message.content.message).messageId,
          );
          break;
        default:
          break;
      }
    });

    // This event is launched when a broadcast message has been received, the structure
    // of the dictionary received is explained in the appendix.
    bridgefyEmitter.addListener('onBroadcastMessageReceived', (message) => {
      console.log('onBroadcastMessageReceived: ' + JSON.stringify(message));
      switch (message.content.type) {
        case 'MESSAGE':
          props.messageActions.messageAdd(message);
          break;
        case 'MESSAGE_EDIT':
          props.messageActions.messageEdit(
            JSON.parse(message.content.message).messageId,
            JSON.parse(message.content.message).text,
          );
          props.bridgefyActions.messageRefresh(message.uuid);
          break;
        case 'MESSAGE_DELETE':
          props.messageActions.messageDelete(
            JSON.parse(message.content.message).messageId,
          );
          break;
        case 'MESSAGE_READ':
          //
          break;
        default:
          break;
      }
    });

    // This event is launched when a message could not be sent, it receives an error
    // whose structure will be explained in the appendix
    bridgefyEmitter.addListener('onMessageFailed', (evt) => {
      console.log('onMessageFailed: ' + evt);
    });

    // This event is launched when a message was sent, contains the message
    // itself, and the structure of message is explained in the appendix.
    bridgefyEmitter.addListener('onMessageSent', (message) => {
      console.log('onMessageSent: ' + JSON.stringify(message));
      // props.bridgefyActions.messageRefresh(message.uuid);
    });

    if (Platform.OS === 'android') {
      bridgefyEmitter.addListener('onMessageDataProgress', (evt) => {
        console.log('onMessageDataProgress: ' + evt.percentageProgress);
        // setSendProgress(evt.percentageProgress);
      });
    }

    // This event is launched when a message was received but it contains errors,
    // the structure for this kind of error is explained in the appendix.
    // This method is launched exclusively on Android.
    bridgefyEmitter.addListener('onMessageReceivedException', (evt) => {
      console.log('onMessageReceivedException: ' + evt);
    });

    //
    // Device listeners
    //

    // This event is launched when the service has been started successfully, it receives
    // a device dictionary that will be descripted in the appendix.
    bridgefyEmitter.addListener('onStarted', (device) => {
      // For now, device is an empty dictionary
      console.log('-------BRIDGEFY SDK STARTED--------', device);
      props.bridgefyActions.bridgefyStart({id: userId, name: userId});
      props.userActions.deviceInit();
      props.navigation.navigate('TabNav');
    });

    // This event is launched when the RNBridgefy service fails on the start, it receives
    // a dictionary (error) that will be explained in the appendix.
    bridgefyEmitter.addListener('onStartError', (evt) => {
      console.log('onStartError: ', evt);
    });

    // This event is launched when the RNBridgefy service stops.
    bridgefyEmitter.addListener('onStopped', (evt) => {
      console.log('onStopped');
      props.bridgefyActions.bridgefyStop();
      props.messageActions.messageInit();
    });

    // This method is launched when a device is nearby and has established connection with the local user.
    // It receives a device dictionary.
    bridgefyEmitter.addListener('onDeviceConnected', (device) => {
      console.log('onDeviceConnected: ' + JSON.stringify(device));
      props.userActions.deviceConnect(device);
    });
    // This method is launched when there is a disconnection of a user.
    bridgefyEmitter.addListener('onDeviceLost', (device) => {
      console.log('onDeviceLost: ' + JSON.stringify(device));
      props.userActions.deviceDisconnect(device);
    });

    // This is method is launched exclusively on iOS devices, notifies about certain actions like when
    // the bluetooth interface  needs to be activated, when internet is needed and others.
    bridgefyEmitter.addListener('onEventOccurred', (event) => {
      console.log(
        'Event code: ' + event.code + ' Description: ' + event.description,
      );
    });
  };

  let initBrdg = () => {
    function doInitBrdg() {
      RNBridgefy.init(BRDG_LICENSE_KEY)
        .then((brdgClient) => {
          console.log('Brdg client = ', brdgClient);
          userId = brdgClient.userUuid;
          RNBridgefy.start({
            autoConnect: true,
            engineProfile: 'BFConfigProfileDefault',
            energyProfile: 'HIGH_PERFORMANCE',
            encryption: true,
          });
        })
        .catch((e) => {
          console.log(e);
        });
    }
    if (Platform.OS === 'android') {
      PermissionsAndroid.requestMultiple([
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        PermissionsAndroid.PERMISSIONS.ACCESS_COARSE_LOCATION,
      ])
        .then((result) => {
          if (
            result['android.permission.ACCESS_COARSE_LOCATION'] ||
            result['android.permission.ACCESS_FINE_LOCATION']
          ) {
            doInitBrdg();
          } else {
          }
        })
        .catch((e) => {});
    } else {
      doInitBrdg();
    }
  };

  return (
    <>
      <View style={styles.container}>
        <ActivityIndicator size="large" color={color.second} />
      </View>
    </>
  );
};

const mapStateToProps = (state) => {
  return {bridgefy: state.bridgefy};
};

const mapDispatchToProps = (dispatch) => {
  return {
    bridgefyActions: bindActionCreators(BridgefyActions, dispatch),
    messageActions: bindActionCreators(MessageActions, dispatch),
    userActions: bindActionCreators(UserActions, dispatch),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Progress);
