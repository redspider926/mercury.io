import {StyleSheet} from 'react-native';
import * as color from '@config/color';

export default StyleSheet.create({
  container: {
    width: '100%',
    height: '100%',
    backgroundColor: color.first,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
