import React, {useState} from 'react';
import {View, Text, TouchableOpacity, Image} from 'react-native';
import Input from '@components/Input';
import Icon from '@components/Icon';

import * as images from '@config/images';
import * as color from '@config/color';
import styles from './style';
import shareStyles from '@config/style';

const Register = (props) => {
  return (
    <>
      <View style={[shareStyles.root, styles.root]}>
        <View style={styles.container}>
          <Image source={images.images.logo} style={styles.logo} />
          <View style={styles.space2} />
          <Text style={styles.title}>Welcome to Mercury</Text>

          <View style={styles.space2} />
          <View style={styles.socialView}>
            <TouchableOpacity style={[styles.socialItem, shareStyles.shadow]}>
              <Icon
                source={images.icons.instagram}
                size={30}
                color={color.first}
              />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.socialItem, shareStyles.shadow]}>
              <Icon
                source={images.icons.soundcloud}
                size={40}
                color={color.first}
              />
            </TouchableOpacity>
          </View>
          <View style={styles.space2} />

          <Input placeholder="" type="email" title="Email" />
          <Input placeholder="" type="password" title="Password" />
          <Input placeholder="" type="password" title="Password" />

          <View style={styles.view1}>
            <TouchableOpacity>
              <Text style={styles.text}>Forget Password?</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.authButton, shareStyles.shadow]}
              onPress={() => {
                props.navigation.navigate('Permissions');
              }}>
              <Text style={styles.authButtonText}>Sign up</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.space2} />
          <TouchableOpacity onPress={() => props.navigation.navigate('Login')}>
            <Text style={styles.text}>Do you want to create account?</Text>
          </TouchableOpacity>
        </View>
      </View>
    </>
  );
};

export default Register;
