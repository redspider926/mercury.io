import React, {useState} from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
import Icon from '@components/Icon';
import {Switch} from 'react-native-switch';
import Input from '@components/Input';

import * as images from '@config/images';
import * as color from '@config/color';
import styles from './style';
import shareStyles from '@config/style';

const Setting = (props) => {
  // const [soundState, setSoundState] = useState(false);
  // const [bluetoothState, setBluetoothState] = useState(false);
  const [notifications, setNotifications] = useState(false);
  const [read, setRead] = useState(false);
  const [bluetooth, setBluetooth] = useState(false);
  const [location, setLocation] = useState(false);
  return (
    <>
      <View style={[shareStyles.root, styles.root]}>
        {/* <Progress.Circle size={30} indeterminate={true} /> */}
        <View style={styles.view1}>
          <Text style={styles.title}>SETTING</Text>
        </View>
        <View style={styles.view2}>
          <View style={styles.group}>
            <Text style={styles.titleText}>MY ACCOUNT</Text>
            <Input type="username" value="redspider" />
          </View>

          <View style={styles.group}>
            <Text style={styles.titleText}>MESSAGES</Text>
            <View style={styles.settingItem}>
              <Text style={styles.itemText}>Enable message notifications</Text>
              <Switch
                value={notifications}
                onValueChange={(val) => setNotifications(!notifications)}
                disabled={false}
                circleSize={20}
                barHeight={25}
                circleBorderWidth={0}
                backgroundActive={color.success}
                backgroundInactive={color.gray}
                circleActiveColor={color.second}
                circleInActiveColor={color.second}
                changeValueImmediately={true}
                renderInsideCircle={() => {}} // custom component to render inside the Switch circle (Text, Image, etc.)
                // if rendering inside circle, change state immediately or wait for animation to complete
                innerCircleStyle={{}} // style for inner animated circle for what you (may) be rendering inside the circle
                outerCircleStyle={{}} // style for outer animated circle
                renderActiveText={false}
                renderInActiveText={false}
                switchLeftPx={2} // denominator for logic when sliding to TRUE position. Higher number = more space from RIGHT of the circle to END of the slider
                switchRightPx={2} // denominator for logic when sliding to FALSE position. Higher number = more space from LEFT of the circle to BEGINNING of the slider
                switchWidthMultiplier={2.2} // multipled by the `circleSize` prop to calculate total width of the Switch
                switchBorderRadius={30} // Sets the border Radius of the switch slider. If unset, it remains the circleSize.
              />
            </View>
            <View style={styles.line} />
            <View style={styles.settingItem}>
              <View>
                <Text style={styles.itemText}>Read receipts</Text>
                <Text style={styles.itemText}>
                  Send message read receipts when {'\n'}opening conversations
                </Text>
              </View>
              <Switch
                value={read}
                onValueChange={(val) => setRead(!read)}
                disabled={false}
                circleSize={20}
                barHeight={25}
                circleBorderWidth={0}
                backgroundActive={color.success}
                backgroundInactive={color.gray}
                circleActiveColor={color.second}
                circleInActiveColor={color.second}
                changeValueImmediately={true}
                renderInsideCircle={() => {}} // custom component to render inside the Switch circle (Text, Image, etc.)
                // if rendering inside circle, change state immediately or wait for animation to complete
                innerCircleStyle={{}} // style for inner animated circle for what you (may) be rendering inside the circle
                outerCircleStyle={{}} // style for outer animated circle
                renderActiveText={false}
                renderInActiveText={false}
                switchLeftPx={2} // denominator for logic when sliding to TRUE position. Higher number = more space from RIGHT of the circle to END of the slider
                switchRightPx={2} // denominator for logic when sliding to FALSE position. Higher number = more space from LEFT of the circle to BEGINNING of the slider
                switchWidthMultiplier={2.2} // multipled by the `circleSize` prop to calculate total width of the Switch
                switchBorderRadius={30} // Sets the border Radius of the switch slider. If unset, it remains the circleSize.
              />
            </View>
            <View style={styles.line} />
            <View style={styles.settingItem}>
              <Text style={styles.itemText}>Notification sound</Text>
            </View>
            <View style={styles.line} />
          </View>

          <View style={styles.group}>
            <Text style={styles.titleText}>DEVICE</Text>
            <View style={styles.settingItem}>
              <View>
                <Text style={styles.itemText}>Bluetooth</Text>
              </View>
              <Switch
                value={bluetooth}
                onValueChange={(val) => setBluetooth(!bluetooth)}
                disabled={false}
                circleSize={20}
                barHeight={25}
                circleBorderWidth={0}
                backgroundActive={color.success}
                backgroundInactive={color.gray}
                circleActiveColor={color.second}
                circleInActiveColor={color.second}
                changeValueImmediately={true}
                renderInsideCircle={() => {}} // custom component to render inside the Switch circle (Text, Image, etc.)
                // if rendering inside circle, change state immediately or wait for animation to complete
                innerCircleStyle={{}} // style for inner animated circle for what you (may) be rendering inside the circle
                outerCircleStyle={{}} // style for outer animated circle
                renderActiveText={false}
                renderInActiveText={false}
                switchLeftPx={2} // denominator for logic when sliding to TRUE position. Higher number = more space from RIGHT of the circle to END of the slider
                switchRightPx={2} // denominator for logic when sliding to FALSE position. Higher number = more space from LEFT of the circle to BEGINNING of the slider
                switchWidthMultiplier={2.2} // multipled by the `circleSize` prop to calculate total width of the Switch
                switchBorderRadius={30} // Sets the border Radius of the switch slider. If unset, it remains the circleSize.
              />
            </View>
            <View style={styles.line} />

            <View style={styles.settingItem}>
              <View>
                <Text style={styles.itemText}>Location</Text>
              </View>
              <Switch
                value={location}
                onValueChange={(val) => setLocation(!location)}
                disabled={false}
                circleSize={20}
                barHeight={25}
                circleBorderWidth={0}
                backgroundActive={color.success}
                backgroundInactive={color.gray}
                circleActiveColor={color.second}
                circleInActiveColor={color.second}
                changeValueImmediately={true}
                renderInsideCircle={() => {}} // custom component to render inside the Switch circle (Text, Image, etc.)
                // if rendering inside circle, change state immediately or wait for animation to complete
                innerCircleStyle={{}} // style for inner animated circle for what you (may) be rendering inside the circle
                outerCircleStyle={{}} // style for outer animated circle
                renderActiveText={false}
                renderInActiveText={false}
                switchLeftPx={2} // denominator for logic when sliding to TRUE position. Higher number = more space from RIGHT of the circle to END of the slider
                switchRightPx={2} // denominator for logic when sliding to FALSE position. Higher number = more space from LEFT of the circle to BEGINNING of the slider
                switchWidthMultiplier={2.2} // multipled by the `circleSize` prop to calculate total width of the Switch
                switchBorderRadius={30} // Sets the border Radius of the switch slider. If unset, it remains the circleSize.
              />
            </View>
            <View style={styles.line} />
          </View>
          {/* <TouchableOpacity style={styles.buttonSave}>
            <Text style={styles.textButton}>Save setting</Text>
          </TouchableOpacity> */}
        </View>
      </View>
    </>
  );
};

export default Setting;
