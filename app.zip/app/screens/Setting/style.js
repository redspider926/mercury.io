import {StyleSheet} from 'react-native';
import * as dimension from '@config/dimension';
import * as color from '@config/color';

export default StyleSheet.create({
  root: {
    backgroundColor: color.first,
  },

  title: {
    fontSize: dimension.fontSize.font2,
    color: color.second,
  },

  image: {
    width: 150,
    height: 150,
    borderRadius: 100,
  },

  view1: {
    height: dimension.size.size_header,
    width: '100%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },

  view2: {
    flex: 1,
    width: '100%',
    backgroundColor: color.second,
    borderTopRightRadius: dimension.size.size_normal,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: dimension.size.padding,
  },

  buttonSave: {
    width: '100%',
    height: dimension.size.size_normal,
    borderRadius: dimension.size.size1,
    backgroundColor: color.first,
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 5,
  },

  textButton: {
    color: color.second,
    fontSize: dimension.fontSize.font2,
    marginLeft: 10,
  },

  settingItem: {
    width: '100%',
    display: 'flex',
    flexDirection: 'row',
    marginTop: 20,
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },

  itemText: {
    fontSize: dimension.fontSize.font1,
    color: color.black,
  },

  line: {
    width: '100%',
    height: 2,
    backgroundColor: color.gray,
    marginTop: 5,
  },

  titleText: {
    fontSize: dimension.fontSize.font1,
    fontWeight: 'bold',
  },

  group: {
    width: '100%',
  },
});
