import React, {Component} from 'react';
import {View, Text} from 'react-native';

class Splash extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <>
        <View style={{backgroundColor: 'red', width: '100%', height: '100%'}} />
      </>
    );
  }
}

export default Splash;
