import React, {useState} from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
import {Switch} from 'react-native-switch';

import * as images from '@config/images';
import * as color from '@config/color';
import styles from './style';
import shareStyles from '@config/style';

const Start = (props) => {
  return (
    <>
      <View style={[shareStyles.root, styles.root]}>
        <View style={styles.container}>
          <Image style={styles.image} source={images.images.start} />
          <View style={styles.carousel}>
            <View
              style={[styles.carousel_child, {backgroundColor: color.gray}]}
            />
            <View style={styles.carousel_child} />
          </View>
          <Text style={styles.title}>Search Nearby &amp; Chat</Text>
          <Text style={styles.text}>
            There are many variations of passages of Ipsum available, but the
            majority have suﬀered alteration in some form
          </Text>
          <View style={styles.view1} />
        </View>
        <View style={styles.view4}>
          <TouchableOpacity
            onPress={() => {
              props.navigation.navigate('Bluetooth');
            }}
            style={styles.button}>
            <Text style={styles.buttonText}>BACK</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              props.navigation.navigate('TabNav');
            }}
            style={styles.button}>
            <Text style={styles.buttonText}>NEXT</Text>
          </TouchableOpacity>
        </View>
      </View>
    </>
  );
};

export default Start;
