import {StyleSheet} from 'react-native';
import * as dimension from '@config/dimension';
import * as color from '@config/color';

export default StyleSheet.create({
  container: {
    backgroundColor: color.first,
    width: '100%',
    height: '85%',
    borderBottomLeftRadius: dimension.size.size_normal,
    borderBottomRightRadius: dimension.size.size_normal,
    padding: dimension.size.size_normal,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  root: {backgroundColor: color.second},

  image: {
    width: 250,
    height: 250,
  },

  carousel: {
    display: 'flex',
    flexDirection: 'row',
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },

  carousel_child: {
    width: 16,
    height: 16,
    backgroundColor: color.blue,
    borderRadius: 10,
    margin: 8,
  },

  title: {
    fontSize: dimension.fontSize.font3,
    fontWeight: 'bold',
    color: color.second,
  },

  text: {
    color: color.second,
    fontSize: dimension.fontSize.font2,
    marginLeft: 10,
    textAlign: 'center',
  },

  view1: {
    height: 50,
  },

  view4: {
    width: '100%',
    height: '15%',
    display: 'flex',
    paddingLeft: dimension.size.size_normal,
    paddingRight: dimension.size.size_normal,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  button: {
    width: 150,
    height: dimension.size.size_normal,
    backgroundColor: color.orange,
    borderRadius: 30,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },

  buttonText: {
    color: color.first,
    fontSize: dimension.fontSize.font2,
    fontWeight: 'bold',
  },
});
